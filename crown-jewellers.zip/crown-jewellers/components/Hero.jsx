"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import gsap from "gsap";
import GoldDust from "./GoldDust";
import JewelIcon from "./JewelIcons";
import { site } from "@/config/site";

const rotating = ["Elegant Designs", "Trusted Quality", "22ct & 24ct Gold", "Sale & Purchase Available"];

export default function Hero() {
  const root = useRef(null);
  const [i, setI] = useState(0);

  // Mouse parallax for the 3D glass stack
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const rotY = useSpring(useTransform(mx, [-0.5, 0.5], [-9, 9]), { stiffness: 80, damping: 18 });
  const rotX = useSpring(useTransform(my, [-0.5, 0.5], [7, -7]), { stiffness: 80, damping: 18 });
  const shiftX = useSpring(useTransform(mx, [-0.5, 0.5], [-18, 18]), { stiffness: 60, damping: 20 });
  const shiftY = useSpring(useTransform(my, [-0.5, 0.5], [-12, 12]), { stiffness: 60, damping: 20 });

  const onMove = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    mx.set((e.clientX - r.left) / r.width - 0.5);
    my.set((e.clientY - r.top) / r.height - 0.5);
  };
  const onLeave = () => {
    mx.set(0);
    my.set(0);
  };

  // One orchestrated entrance with GSAP
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: "power3.out" } });
      tl.from("[data-hero='crest']", { scale: 0.6, opacity: 0, duration: 0.9 })
        .from("[data-hero='title'] span", { yPercent: 110, opacity: 0, duration: 1, stagger: 0.12 }, "-=0.4")
        .from("[data-hero='tag']", { opacity: 0, y: 18, duration: 0.8 }, "-=0.5")
        .from("[data-hero='cta'] > *", { opacity: 0, y: 18, duration: 0.7, stagger: 0.12 }, "-=0.4")
        .from("[data-hero='orb']", { scale: 0, opacity: 0, duration: 1.2, stagger: 0.15, ease: "back.out(1.6)" }, 0.2);
      gsap.to("[data-hero='orb']", {
        y: "random(-26, 26)",
        x: "random(-18, 18)",
        duration: "random(3.5, 6)",
        ease: "sine.inOut",
        repeat: -1,
        yoyo: true,
        stagger: { each: 0.4, from: "random" },
      });
    }, root);
    return () => ctx.revert();
  }, []);

  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % rotating.length), 2800);
    return () => clearInterval(t);
  }, []);

  return (
    <section
      id="home"
      ref={root}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      className="relative isolate flex min-h-[100svh] items-center overflow-hidden bg-gradient-to-b from-navy-950 via-navy-900 to-navy-800 pt-28 pb-20"
    >
      {/* Ambient depth */}
      <div aria-hidden className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_70%_20%,rgba(30,65,117,0.55),transparent_60%),radial-gradient(ellipse_at_10%_90%,rgba(212,175,55,0.12),transparent_55%)]" />
      <GoldDust />

      {/* Floating glass orbs */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-0">
        <div data-hero="orb" className="absolute left-[6%] top-[22%] h-24 w-24 rounded-full bg-gradient-to-br from-gold/50 to-transparent blur-[2px] glass sm:h-36 sm:w-36" />
        <div data-hero="orb" className="absolute bottom-[14%] left-[40%] h-14 w-14 rounded-full bg-gradient-to-br from-gold-bright/40 to-transparent glass sm:h-20 sm:w-20" />
        <div data-hero="orb" className="absolute right-[8%] top-[12%] h-16 w-16 rounded-full bg-gradient-to-br from-navy-600 to-gold/30 glass sm:h-28 sm:w-28" />
      </div>

      <div className="relative z-10 mx-auto grid w-full max-w-7xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-[1.15fr_0.85fr]">
        {/* Copy */}
        <div>
          <div data-hero="crest" className="mb-6 inline-flex items-center gap-3 rounded-full border border-gold/40 bg-navy-800/60 px-4 py-2 text-sm text-gold-soft backdrop-blur">
            <span className="h-2 w-2 rounded-full bg-gold-bright shadow-goldglow" />
            Manchester&apos;s trusted gold jewellers
          </div>

          <h1
            data-hero="title"
            className="font-display text-[clamp(3.2rem,9vw,7rem)] font-semibold leading-[0.95] tracking-tight"
          >
            <span className="block overflow-hidden pb-2"><span className="block gold-text">Crown</span></span>
            <span className="block overflow-hidden pb-2"><span className="block text-[#f6f0dc]">Jewellers</span></span>
          </h1>

          <p data-hero="tag" className="mt-6 max-w-xl font-display text-xl italic leading-snug text-gold-soft sm:text-2xl">
            {site.tagline}
          </p>

          <div className="mt-4 h-8 text-lg text-[#e9e4d2]/80" aria-live="polite">
            <AnimatePresence mode="wait">
              <motion.span
                key={i}
                initial={{ opacity: 0, y: 12, filter: "blur(4px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -12, filter: "blur(4px)" }}
                transition={{ duration: 0.45 }}
                className="inline-block"
              >
                {rotating[i]}
              </motion.span>
            </AnimatePresence>
          </div>

          <div data-hero="cta" className="mt-9 flex flex-wrap gap-4">
            <a href="#categories" className="btn-gold text-base">
              Explore Collection
            </a>
            <a href="#contact" className="btn-outline text-base">
              Visit our shop
            </a>
          </div>
        </div>

        {/* 3D glass stack */}
        <div className="relative mx-auto hidden h-[440px] w-full max-w-md lg:block" style={{ perspective: 1100 }}>
          <motion.div
            style={{ rotateX: rotX, rotateY: rotY, transformStyle: "preserve-3d" }}
            className="relative h-full w-full"
          >
            <motion.div
              style={{ x: shiftX, y: shiftY, translateZ: -40 }}
              className="glass absolute inset-x-6 top-4 bottom-10 rounded-[2rem] opacity-60"
            />
            <div
              className="glass absolute inset-x-0 top-12 bottom-0 grid place-items-center rounded-[2rem]"
              style={{ transform: "translateZ(30px)" }}
            >
              <div className="absolute inset-4 rounded-[1.5rem] border border-gold/30" />
              <JewelIcon name="ring" className="h-44 w-44 text-gold-bright drop-shadow-[0_0_24px_rgba(255,215,0,0.55)]" />
              <p className="absolute bottom-8 font-display text-2xl text-gold-soft">22ct &amp; 24ct Gold</p>
            </div>
            <div
              className="glass absolute -right-4 top-0 rounded-2xl px-5 py-4"
              style={{ transform: "translateZ(90px)" }}
            >
              <p className="font-display text-3xl gold-text">Gold</p>
              <p className="text-sm text-[#e9e4d2]/80">Sale &amp; Purchase</p>
            </div>
            <div
              className="glass absolute -left-6 bottom-16 rounded-2xl px-5 py-4"
              style={{ transform: "translateZ(70px)" }}
            >
              <p className="font-display text-xl text-gold-soft">608 Stockport Road</p>
              <p className="text-sm text-[#e9e4d2]/80">Manchester M13 0RQ</p>
            </div>
          </motion.div>
        </div>
      </div>

      <div aria-hidden className="absolute inset-x-0 bottom-0 h-px gold-divider" />
    </section>
  );
}
