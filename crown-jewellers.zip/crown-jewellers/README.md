# Crown Jewellers website

Next.js 14 + Tailwind CSS + Framer Motion + GSAP.

## Run it
```bash
npm install
npm run dev      # http://localhost:3000
npm run build && npm start
```

## Where to change things
| What | File |
|------|------|
| Logo, phone, WhatsApp number, address, social links | `config/site.js` |
| Category cards (title, text, photo) | `data/categories.js` |
| Products (name, gold purity, price, photo) | `data/products.js` |
| Logo / product photos | put files in `public/images/` and reference them in the files above |
| Colours and fonts | `tailwind.config.js`, `app/globals.css` |

## Important: WhatsApp number
`config/site.js` uses 441612223636 (your landline in international format).
WhatsApp only works on a mobile or WhatsApp Business number, so replace it
with your WhatsApp number (digits only, e.g. 447123456789).

## Facebook link
Set the exact page URL in `config/site.js` under `social.facebook.url`.
