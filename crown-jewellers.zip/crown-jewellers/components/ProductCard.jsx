"use client";

import { motion } from "framer-motion";
import JewelIcon from "./JewelIcons";
import { WhatsAppIcon } from "./Icons";
import { categories } from "@/data/categories";
import { productMessage, whatsappLink } from "@/lib/whatsapp";

export default function ProductCard({ product }) {
  const cat = categories.find((c) => c.id === product.category);

  return (
    <motion.article
      layout
      initial={{ opacity: 0, scale: 0.94 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.94 }}
      transition={{ duration: 0.35 }}
      whileHover={{ y: -6 }}
      className="group flex flex-col overflow-hidden rounded-3xl glass"
    >
      {/* Image: replace by setting `image` in data/products.js */}
      <div className="relative aspect-[4/3] overflow-hidden bg-gradient-to-br from-navy-700 to-navy-900">
        {product.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        ) : (
          <div className="grid h-full w-full place-items-center">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(212,175,55,0.22),transparent_65%)]" />
            <JewelIcon
              name={cat?.icon}
              className="relative h-24 w-24 text-gold transition-transform duration-500 group-hover:scale-110"
            />
            <span className="absolute bottom-3 right-4 text-xs text-[#e9e4d2]/50">Product photo</span>
          </div>
        )}
        <span className="absolute left-4 top-4 rounded-full border border-gold/50 bg-navy-900/80 px-3 py-1 text-xs font-medium text-gold-bright backdrop-blur">
          {product.purity}
        </span>
      </div>

      <div className="flex flex-1 flex-col p-6">
        <h3 className="font-display text-2xl font-semibold text-[#f6f0dc]">{product.name}</h3>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-[#e9e4d2]/70">{product.details}</p>
        <div className="my-5 h-px gold-divider" />
        <p className="mb-4 text-lg text-gold-soft">{product.price}</p>
        <a
          href={whatsappLink(productMessage(product))}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-gold w-full"
          aria-label={`Order ${product.name} on WhatsApp`}
        >
          <WhatsAppIcon width={20} height={20} />
          Order Now / Inquire on WhatsApp
        </a>
      </div>
    </motion.article>
  );
}
