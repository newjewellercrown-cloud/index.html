import "./globals.css";
import { site } from "@/config/site";

export const metadata = {
  title: `${site.name} | 22ct & 24ct Gold Jewellery, Manchester`,
  description:
    "Crown Jewellers, 608 Stockport Road, Manchester. 22ct and 24ct gold jewellery, rings, earrings, malas, bangles and nose pins. Gold sale and purchase available.",
};

export const viewport = {
  themeColor: "#0A192F",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en-GB">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;0,700;1,500&family=Jost:wght@300;400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
