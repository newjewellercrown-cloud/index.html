import Logo from "./Logo";
import { FacebookIcon, InstagramIcon, PhoneIcon, PinIcon, ShieldIcon, TikTokIcon, WhatsAppIcon } from "./Icons";
import { site } from "@/config/site";
import { whatsappLink } from "@/lib/whatsapp";

const socialIcons = {
  instagram: InstagramIcon,
  facebook: FacebookIcon,
  tiktok: TikTokIcon,
};

export default function Footer() {
  return (
    <footer id="contact" className="relative bg-navy-950">
      <div className="h-px gold-divider" />
      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
        <div className="grid gap-12 md:grid-cols-3">
          <div>
            <Logo />
            <p className="mt-5 max-w-xs leading-relaxed text-[#e9e4d2]/75">{site.tagline}</p>
            <div className="mt-6 inline-flex items-center gap-3 rounded-full border border-gold/60 bg-gold/10 px-5 py-2.5 text-gold-bright shadow-gold">
              <ShieldIcon width={20} height={20} />
              <span className="font-medium">Gold Sale &amp; Purchase Available</span>
            </div>
          </div>

          <div>
            <h3 className="font-display text-2xl font-semibold text-gold-soft">Visit &amp; contact</h3>
            <div className="my-4 h-px w-24 gold-divider" />
            <ul className="space-y-4 text-[#e9e4d2]/85">
              <li>
                <a href={site.address.mapsUrl} target="_blank" rel="noopener noreferrer" className="flex gap-3 hover:text-gold-bright">
                  <PinIcon className="mt-1 shrink-0 text-gold" />
                  <span>
                    📍 {site.address.line1},<br />
                    {site.address.line2}, {site.address.country}
                  </span>
                </a>
              </li>
              <li>
                <a href={`tel:${site.phone.tel}`} className="flex items-center gap-3 hover:text-gold-bright">
                  <PhoneIcon className="shrink-0 text-gold" />
                  <span>📞 {site.phone.display}</span>
                </a>
              </li>
              <li>
                <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 hover:text-gold-bright">
                  <WhatsAppIcon className="shrink-0 text-gold" />
                  <span>Message us on WhatsApp</span>
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-display text-2xl font-semibold text-gold-soft">Follow us</h3>
            <div className="my-4 h-px w-24 gold-divider" />
            <ul className="space-y-4">
              {Object.entries(site.social).map(([key, s]) => {
                const Icon = socialIcons[key];
                return (
                  <li key={key}>
                    <a
                      href={s.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group flex items-center gap-4 text-[#e9e4d2]/85 hover:text-gold-bright"
                    >
                      <span className="grid h-11 w-11 place-items-center rounded-full border border-gold/50 text-gold transition-all group-hover:border-gold-bright group-hover:bg-gold group-hover:text-navy-900 group-hover:shadow-goldglow">
                        <Icon />
                      </span>
                      <span>
                        <span className="block text-sm text-[#e9e4d2]/60">{s.label}</span>
                        {s.handle}
                      </span>
                    </a>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>

        <div className="mt-14 h-px gold-divider" />
        <p className="mt-6 text-center text-sm text-[#e9e4d2]/55">
          &copy; {new Date().getFullYear()} {site.name}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
