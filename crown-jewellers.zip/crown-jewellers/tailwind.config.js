/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          950: "#050d1a",
          900: "#0A192F",
          800: "#0f2340",
          700: "#16315a",
          600: "#1e4175",
        },
        gold: {
          DEFAULT: "#D4AF37",
          bright: "#FFD700",
          soft: "#F1D77A",
          deep: "#9C7A1E",
        },
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', "Georgia", "serif"],
        sans: ["Jost", "system-ui", "sans-serif"],
      },
      boxShadow: {
        gold: "0 0 0 1px rgba(212,175,55,.35), 0 10px 40px -10px rgba(212,175,55,.35)",
        goldglow: "0 0 30px rgba(255,215,0,.35)",
      },
    },
  },
  plugins: [],
};
