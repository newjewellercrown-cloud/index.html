/**
 * Line-art jewellery icons used when a category or product has no photo yet.
 * Keys match `icon` in data/categories.js.
 */
const stroke = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.6,
  strokeLinecap: "round",
  strokeLinejoin: "round",
};

const icons = {
  ring: (
    <>
      <circle cx="32" cy="40" r="15" {...stroke} />
      <circle cx="32" cy="40" r="11" {...stroke} opacity=".5" />
      <path d="M26 22l6-9 6 9-6 7-6-7Z" {...stroke} />
      <path d="M26 22h12" {...stroke} />
    </>
  ),
  earring: (
    <>
      <circle cx="32" cy="14" r="3" {...stroke} />
      <path d="M32 17v10" {...stroke} />
      <path d="M22 27h20l-4 22a6 6 0 0 1-12 0l-4-22Z" {...stroke} />
      <path d="M26 35h12" {...stroke} opacity=".5" />
    </>
  ),
  necklace: (
    <>
      <path d="M10 14c0 22 10 32 22 32s22-10 22-32" {...stroke} />
      <path d="M17 18c2 14 8 22 15 22s13-8 15-22" {...stroke} opacity=".5" />
      <path d="M32 46l-4 6 4 6 4-6-4-6Z" {...stroke} />
    </>
  ),
  bangle: (
    <>
      <ellipse cx="32" cy="34" rx="22" ry="14" {...stroke} />
      <ellipse cx="32" cy="34" rx="17" ry="10" {...stroke} opacity=".5" />
      <path d="M14 30c4 3 9 4 18 4s14-1 18-4" {...stroke} opacity=".5" />
    </>
  ),
  nosepin: (
    <>
      <path d="M32 14c-8 4-14 10-14 20 0 8 6 14 14 14s14-6 14-14c0-10-6-16-14-20Z" {...stroke} opacity=".45" />
      <circle cx="42" cy="34" r="4.5" {...stroke} />
      <path d="M42 29.5v-3M46.5 34h3M42 38.5v3" {...stroke} />
    </>
  ),
  custom: (
    <>
      <path d="M18 24l8-10h12l8 10-14 26L18 24Z" {...stroke} />
      <path d="M18 24h28M26 14l6 36M38 14l-6 36" {...stroke} opacity=".5" />
    </>
  ),
};

export default function JewelIcon({ name = "ring", className = "", ...rest }) {
  return (
    <svg
      viewBox="0 0 64 64"
      className={className}
      role="img"
      aria-hidden="true"
      {...rest}
    >
      {icons[name] || icons.ring}
    </svg>
  );
}
