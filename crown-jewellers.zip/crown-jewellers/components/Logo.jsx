import { site } from "@/config/site";
import { CrownIcon } from "./Icons";

/** Shows your logo image if set in config/site.js, otherwise a crest placeholder. */
export default function Logo({ size = 44 }) {
  return (
    <span className="flex items-center gap-3">
      {site.logo ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={site.logo} alt={`${site.name} logo`} style={{ height: size }} className="w-auto" />
      ) : (
        <span
          className="grid place-items-center rounded-full border border-gold/60 bg-navy-800 text-gold shadow-gold"
          style={{ width: size, height: size }}
          title="Crown Jewellers Logo"
        >
          <CrownIcon width={size * 0.5} height={size * 0.5} />
        </span>
      )}
      <span className="font-display text-2xl font-semibold leading-none tracking-wide gold-text">
        {site.name}
      </span>
    </span>
  );
}
