"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import CategoryCard from "./CategoryCard";
import ProductCard from "./ProductCard";
import { categories } from "@/data/categories";
import { products } from "@/data/products";

function SectionTitle({ title, children }) {
  return (
    <div className="mx-auto mb-14 max-w-2xl text-center">
      <h2 className="font-display text-4xl font-semibold text-[#f6f0dc] sm:text-5xl">{title}</h2>
      <div className="mx-auto mt-5 h-px w-40 gold-divider" />
      {children && <p className="mt-5 text-lg leading-relaxed text-[#e9e4d2]/75">{children}</p>}
    </div>
  );
}

/** Categories grid + product list. Tapping a category filters the products below. */
export default function Collection() {
  const [active, setActive] = useState("all");

  const choose = (id) => {
    const next = active === id ? "all" : id;
    setActive(next);
    if (next !== "all") {
      document.getElementById("collection")?.scrollIntoView({ behavior: "smooth" });
    }
  };

  const shown = active === "all" ? products : products.filter((p) => p.category === active);

  return (
    <>
      <section id="categories" className="relative bg-navy-900 py-24">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <SectionTitle title="Shop by category">
            Choose a category to see what we have in 22ct and 24ct gold.
          </SectionTitle>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {categories.map((c, i) => (
              <CategoryCard key={c.id} category={c} index={i} active={active === c.id} onSelect={choose} />
            ))}
          </div>
        </div>
      </section>

      <section id="collection" className="relative bg-gradient-to-b from-navy-900 to-navy-950 py-24">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <SectionTitle title="Gold & Silver Collection">
            Tap Order Now on any piece and we will reply on WhatsApp with today&apos;s price and availability.
          </SectionTitle>

          <div className="mb-12 flex flex-wrap justify-center gap-3" role="group" aria-label="Filter by category">
            {[{ id: "all", title: "All pieces" }, ...categories].map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setActive(c.id)}
                aria-pressed={active === c.id}
                className={`rounded-full border px-5 py-2 text-sm transition-all ${
                  active === c.id
                    ? "border-gold-bright bg-gold text-navy-900 shadow-goldglow"
                    : "border-gold/40 text-gold-soft hover:border-gold-bright hover:text-gold-bright"
                }`}
              >
                {c.title}
              </button>
            ))}
          </div>

          <motion.div layout className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            <AnimatePresence mode="popLayout">
              {shown.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </AnimatePresence>
          </motion.div>
        </div>
      </section>
    </>
  );
}
