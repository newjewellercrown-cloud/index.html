"use client";

import { motion, useMotionTemplate, useMotionValue, useSpring, useTransform } from "framer-motion";
import JewelIcon from "./JewelIcons";

/** 3D tilt card. Tilts toward the pointer and shows a moving gold glare. */
export default function CategoryCard({ category, active, onSelect, index }) {
  const x = useMotionValue(0.5);
  const y = useMotionValue(0.5);

  const rotateY = useSpring(useTransform(x, [0, 1], [-12, 12]), { stiffness: 220, damping: 18 });
  const rotateX = useSpring(useTransform(y, [0, 1], [12, -12]), { stiffness: 220, damping: 18 });
  const glareX = useTransform(x, [0, 1], [0, 100]);
  const glareY = useTransform(y, [0, 1], [0, 100]);
  const glare = useMotionTemplate`radial-gradient(circle at ${glareX}% ${glareY}%, rgba(255,215,0,0.28), transparent 55%)`;

  const move = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    x.set((e.clientX - r.left) / r.width);
    y.set((e.clientY - r.top) / r.height);
  };
  const leave = () => {
    x.set(0.5);
    y.set(0.5);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.6, delay: (index % 3) * 0.08 }}
      style={{ perspective: 900 }}
    >
      <motion.button
        type="button"
        onClick={() => onSelect(category.id)}
        onPointerMove={move}
        onPointerLeave={leave}
        aria-pressed={active}
        style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
        whileTap={{ scale: 0.98 }}
        className={`group relative block h-full w-full overflow-hidden rounded-3xl p-7 text-left glass ${
          active ? "ring-2 ring-gold-bright" : ""
        }`}
      >
        <motion.span aria-hidden style={{ background: glare }} className="pointer-events-none absolute inset-0" />

        <div style={{ transform: "translateZ(50px)" }} className="relative">
          <div className="mb-6 grid h-32 place-items-center overflow-hidden rounded-2xl border border-gold/25 bg-gradient-to-br from-navy-700/70 to-navy-900/70">
            {category.image ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={category.image} alt={category.title} className="h-full w-full object-cover" />
            ) : (
              <JewelIcon
                name={category.icon}
                className="h-20 w-20 text-gold transition-transform duration-500 group-hover:scale-110 group-hover:text-gold-bright"
              />
            )}
          </div>
          <h3 className="font-display text-2xl font-semibold text-[#f6f0dc]">{category.title}</h3>
          <p className="mt-1 text-gold-soft">{category.subtitle}</p>
          <p className="mt-3 text-sm leading-relaxed text-[#e9e4d2]/70">{category.blurb}</p>
          <span className="mt-5 inline-flex items-center gap-2 text-sm text-gold-bright">
            View pieces
            <span aria-hidden className="transition-transform group-hover:translate-x-1">&rarr;</span>
          </span>
        </div>
      </motion.button>
    </motion.div>
  );
}
