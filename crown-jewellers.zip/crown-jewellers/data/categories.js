/**
 * Categories shown in the 3D card grid.
 * `image` is optional: drop a file in /public/images/categories/
 * and set e.g. image: "/images/categories/rings.jpg".
 * `icon` must match a key in components/JewelIcons.jsx.
 */
export const categories = [
  {
    id: "rings",
    title: "Rings",
    subtitle: "Gold & Diamond",
    blurb: "Solitaires, bands and statement rings in 22ct and 24ct gold.",
    icon: "ring",
    image: null,
  },
  {
    id: "earrings",
    title: "Earrings",
    subtitle: "Studs, jhumkas & drops",
    blurb: "From everyday studs to bridal jhumkas.",
    icon: "earring",
    image: null,
  },
  {
    id: "necklaces",
    title: "Mala & Necklaces",
    subtitle: "Chains, sets & malas",
    blurb: "Classic malas and necklace sets for every occasion.",
    icon: "necklace",
    image: null,
  },
  {
    id: "bangles",
    title: "Bangles & Bracelets",
    subtitle: "Solid & patterned",
    blurb: "Traditional bangles and modern bracelets.",
    icon: "bangle",
    image: null,
  },
  {
    id: "nosepins",
    title: "Nose Pins",
    subtitle: "Studs, rings & clips",
    blurb: "Delicate nose pins in pure gold.",
    icon: "nosepin",
    image: null,
  },
  {
    id: "custom",
    title: "Custom Gold & Silver Pieces",
    subtitle: "Sale & purchase available",
    blurb: "Bespoke designs made to order. We also buy and sell gold.",
    icon: "custom",
    image: null,
  },
];
