"use client";

import { motion } from "framer-motion";
import { ShieldIcon } from "./Icons";
import { site } from "@/config/site";

const points = [
  { title: "22ct & 24ct gold", text: "Pure gold pieces, hallmarked and made to last." },
  { title: "Sale & purchase", text: "We buy and sell gold at a fair, clearly explained rate." },
  { title: "Made to order", text: "Bring a design and we will make it in gold or silver." },
];

export default function About() {
  return (
    <section id="about" className="relative overflow-hidden bg-navy-950 py-24">
      <div aria-hidden className="absolute -right-40 top-10 h-96 w-96 rounded-full bg-gold/10 blur-3xl" />
      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="font-display text-4xl font-semibold text-[#f6f0dc] sm:text-5xl">About {site.name}</h2>
          <div className="mt-5 h-px w-32 gold-divider" />
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-[#e9e4d2]/80">
            We are a family-friendly jewellery shop on Stockport Road in Manchester. Whether you are
            choosing a wedding set, a gift or a simple everyday chain, we will help you find the right
            piece and be clear about weight, purity and price.
          </p>
          <p className="mt-4 max-w-xl text-lg leading-relaxed text-[#e9e4d2]/80">
            Message us on WhatsApp with a photo or an idea, or visit the shop and see the pieces in person.
          </p>
        </motion.div>

        <div className="grid gap-5">
          {points.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="glass flex items-start gap-5 rounded-2xl p-6"
            >
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full border border-gold/50 text-gold-bright">
                <ShieldIcon width={22} height={22} />
              </span>
              <div>
                <h3 className="font-display text-xl font-semibold text-[#f6f0dc]">{p.title}</h3>
                <p className="mt-1 text-[#e9e4d2]/75">{p.text}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
