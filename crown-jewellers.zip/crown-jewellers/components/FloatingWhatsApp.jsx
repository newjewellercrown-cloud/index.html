"use client";

import { WhatsAppIcon } from "./Icons";
import { whatsappLink } from "@/lib/whatsapp";

/** Always-visible round WhatsApp button, bottom right. */
export default function FloatingWhatsApp() {
  return (
    <a
      href={whatsappLink()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with Crown Jewellers on WhatsApp"
      className="fixed bottom-5 right-5 z-40 grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-gold-soft to-gold text-navy-900 shadow-gold transition-transform hover:scale-110 hover:shadow-goldglow"
    >
      <WhatsAppIcon width={28} height={28} />
    </a>
  );
}
