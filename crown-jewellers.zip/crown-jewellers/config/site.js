/**
 * ONE PLACE TO EDIT STORE DETAILS.
 * Change the logo, phone numbers, address and social links here and
 * the whole site updates.
 */
export const site = {
  name: "Crown Jewellers",
  tagline: "22ct & 24ct Gold Jewellery | Elegant Designs • Trusted Quality",

  // Put your logo file in /public/images/ (e.g. /public/images/logo.png)
  // then set the path below. Leave as null to show the placeholder crest.
  logo: null, // e.g. "/images/logo.png"

  phone: {
    display: "0161 222 3636",
    // Used for tap-to-call links
    tel: "+441612223636",
  },

  whatsapp: {
    // International format, digits only, no "+" or spaces.
    // 441612223636 is the landline converted to UK format.
    // WhatsApp only works on a mobile number or WhatsApp Business line:
    // replace this with your WhatsApp number, e.g. "447123456789".
    number: "441612223636",
    defaultMessage: "Hi Crown Jewellers, I am interested in inquiring about this product.",
  },

  address: {
    line1: "608 Stockport Road",
    line2: "Manchester, M13 0RQ",
    country: "UK",
    mapsUrl:
      "https://www.google.com/maps/search/?api=1&query=608+Stockport+Road+M13+0RQ+Manchester",
  },

  social: {
    instagram: {
      label: "Instagram",
      handle: "cj6082026",
      url: "https://www.instagram.com/cj6082026",
    },
    facebook: {
      label: "Facebook",
      handle: "crown jewellers",
      // Replace with your exact page URL once you have it
      url: "https://www.facebook.com/search/top?q=crown%20jewellers",
    },
    tiktok: {
      label: "TikTok",
      handle: "crownjewellersmcr",
      url: "https://www.tiktok.com/@crownjewellersmcr",
    },
  },
};
